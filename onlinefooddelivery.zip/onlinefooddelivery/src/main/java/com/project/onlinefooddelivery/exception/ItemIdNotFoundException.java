package com.project.onlinefooddelivery.exception;

public class ItemIdNotFoundException extends  RuntimeException {
	
	public ItemIdNotFoundException(String message) {
		super(message);
	}

}



