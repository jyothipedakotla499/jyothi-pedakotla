package com.project.onlinefooddelivery;

import org.springframework.boot.SpringApplication;


import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinefooddeliveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinefooddeliveryApplication.class, args);
	}

}
