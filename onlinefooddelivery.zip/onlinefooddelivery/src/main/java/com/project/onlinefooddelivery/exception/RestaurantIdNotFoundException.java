package com.project.onlinefooddelivery.exception;

public class RestaurantIdNotFoundException extends  RuntimeException {
	
	public RestaurantIdNotFoundException(String message) {
		super(message);
	}

}




