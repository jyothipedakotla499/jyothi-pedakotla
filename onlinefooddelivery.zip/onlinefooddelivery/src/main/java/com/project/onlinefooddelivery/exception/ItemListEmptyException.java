package com.project.onlinefooddelivery.exception;

public class ItemListEmptyException extends  RuntimeException {
	
	public ItemListEmptyException(String message)
	{
		super(message);
	}

}


