package com.project.onlinefooddelivery.exception;

public class RestaurantListEmptyException extends RuntimeException {
	
	public RestaurantListEmptyException(String message)
	{
		super(message);
	}

}


